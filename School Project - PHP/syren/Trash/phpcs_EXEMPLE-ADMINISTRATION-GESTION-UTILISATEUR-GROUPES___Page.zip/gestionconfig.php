<?php 
#Kilian DESROCHES 
#kilian@desroches.net
include "onglet.php";
	$smarty->assign("gestion_enabled","actif");
	$smarty->assign("titre_page","Configuration global");
	$smarty->assign("explication","Aper�u de l'ensemble des configurations.");
	$smarty->assign("title_base","Configuration g�n�ral");

	$smarty->display('gestionconfig.html');

?>