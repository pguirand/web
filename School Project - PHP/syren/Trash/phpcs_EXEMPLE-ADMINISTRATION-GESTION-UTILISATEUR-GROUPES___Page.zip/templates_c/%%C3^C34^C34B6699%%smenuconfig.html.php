<?php /* Smarty version 2.6.14, created on 2009-03-31 19:56:13
         compiled from smenuconfig.html */ ?>
<ul class="sous_navigation">
			
			
			<li class="polices_et_couleurs <?php echo $this->_tpl_vars['login_enabled']; ?>
"><a href="gestionlogin.php">Gestion des utilisateurs</a></li>
				<li class="polices_et_couleurs <?php echo $this->_tpl_vars['groupe_enabled']; ?>
"><a href="gestiongroupes.php">Gestion des groupes</a></li>
			
			
			<li class="polices_et_couleurs <?php echo $this->_tpl_vars['ip_enabled']; ?>
"><a href="gestionip.php">Gestion des IP</a></li>
		
			
		</ul>