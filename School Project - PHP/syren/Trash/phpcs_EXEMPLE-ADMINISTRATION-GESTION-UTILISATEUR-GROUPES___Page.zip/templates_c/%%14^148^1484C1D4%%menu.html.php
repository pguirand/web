<?php /* Smarty version 2.6.14, created on 2009-03-31 19:56:10
         compiled from menu.html */ ?>
		<ul class="navigation">
			<li class="accueil <?php echo $this->_tpl_vars['accueil_enabled']; ?>
"><a href="accueil.php"><?php echo $this->_tpl_vars['accueil']; ?>
</a></li>
			<li class="gestion <?php echo $this->_tpl_vars['gestion_enabled']; ?>
"><a href="gestionconfig.php"><?php echo $this->_tpl_vars['gestion']; ?>
</a></li>
		
		</ul>