<?php 
#Kilian DESROCHES 
#kilian@desroches.net

include "onglet.php";
require_once('class/MyDb.lib.php');
	require_once('config.inc.php');
	$smarty->assign("gestion_enabled","actif");
	$smarty->assign("login_enabled","actif");
	$smarty->assign("titre_page","Configuration des utilisateurs");
	$smarty->assign("explication","Aper�u de l'ensemble des configurations.");
	$smarty->assign("title_base","Configuration des connexions");

	 	 	 	 	 	 	 	 	 	
	
	$connexion = new MyDb();
	
	if ($listecatd->droit != 1){
		$_GET["id"] = $listecatd->id;
	}
	
	if (!empty($_GET["id"])){
	
	
	if ($_GET["sup"]==1){
	
		if ($listecatd->droit ==1){
		$reqd =  'DELETE FROM ';
		$reqd .= ' table_login  ';
		$reqd .= 'WHERE id="'.$_GET['id'].'"';
		$valeurd = $connexion->execute($reqd);
		
		
		}
		$del=1;
	}

	
	
	if ($_GET["mod"]==1){
	
		$validupdate = TRUE;
		
		if (empty($_POST['prenom'])){
		$smarty->assign("message","Erreur le pr�nom est vide");
		$validupdate= FALSE;
		}
		
		if (empty($_POST['nom'])){
		$smarty->assign("message","Erreur le nom est vide");
		$validupdate= FALSE;
		}
		
		if ($listecatd->droit == 1){
			if (empty($_POST['identifiant'])){
			$smarty->assign("message","Erreur l'identifiant est vide");
			$validupdate= FALSE;
			}
		}
		
		if (empty($_POST['passe'])){
		$smarty->assign("message","Erreur le mot de passe est vide");
		$validupdate= FALSE;
		}
		
		if (empty($_POST['email'])){
		$smarty->assign("message","Erreur l'email est vide");
		$validupdate= FALSE;
		}
		
		if ($_POST['groupe']=="none"){
		$smarty->assign("message","Erreur merci de choisir un groupe");
		$validupdate= FALSE;
		}
		
		if ($listecatd->droit == 1){
			if (empty($_POST['status'])){
			$smarty->assign("message","Erreur merci de s�lectionner un statut");
			$validinsert= FALSE;
			}
			
			if (empty($_POST['droit'])){
			$smarty->assign("message","Erreur merci de s�lectionner un droit");
			$validupdate= FALSE;
			}
		}
		
	
	
		if ($validupdate== TRUE){
			$reqd =  'UPDATE  ';
			$reqd .= ' table_login SET ';
			$reqd .= 'nom="'.$_POST['nom'].'", ';
			$reqd .= 'prenom="'.$_POST['prenom'].'", ';
			
			if ($listecatd->droit == 1){
			$reqd .= 'identifiant="'.$_POST['identifiant'].'", ';
			}
			
			$reqd .= 'passe="'.$_POST['passe'].'", ';
			$reqd .= 'email="'.$_POST['email'].'", ';
			
			if ($listecatd->droit == 1){
			$reqd .= 'droit="'.$_POST['droit'].'", ';
			$reqd .= 'status="'.$_POST['status'].'", ';
			}
			
			$reqd .= 'groupe="'.$_POST['groupe'].'" ';
			$reqd .= 'WHERE id="'.$_GET['id'].'"';
			$valeurd = $connexion->execute($reqd);
			
			$mod=1;
		}
	}
	
	
	$requete_cat = 'SELECT ';
	$requete_cat .= 'id,nom,prenom, ';
	$requete_cat .= 'identifiant, ';
	$requete_cat .= 'passe, ';
	$requete_cat .= 'email , droit,status,groupe ';
	$requete_cat .= 'FROM table_login WHERE  id='.$_GET["id"].'';
	$listecat = $connexion->querySingleItemObject($requete_cat);

	$id = $listecat->id;
	$nom = $listecat->nom;
	$prenom = $listecat->prenom;
	$identifiant = $listecat->identifiant;
	$passe = $listecat->passe;
	$email = $listecat->email;
	$droitd = $listecat->droit;
	$status = $listecat->status;
	$groupe = $listecat->groupe;
	
	if ($mod==1){
	$formedit = "Modification effective <br>";
	}
	
	if ($del==1){
	if ($listecatd->droit != 1){
	 $formedit = "Impossible de supprimer vous n'avez pas de droit administrateur<br>";
	 }else{
	$formedit = "Suppression effective <br>";
	}
	}
	
	 if ($listecatd->droit ==1){
	 $new = "[ <a href='gestionlogin.php'><b>Nouveau utilisateur</b></a> ]";
	 }
	
	
	$smarty->assign("message","Edition de l'utilisateur ". ucfirst(strtolower($nom)) ." ". ucfirst(strtolower($prenom)) ." (".$identifiant.")<br>".$formedit." ".$new."");
	$edit = 1;
	$smarty->assign("modif",1);
	$smarty->assign("id",$id);
	$smarty->assign("nom",$nom);
	$smarty->assign("prenom",$prenom);
	$smarty->assign("identifiant",$identifiant);
	$smarty->assign("passe",$passe);
	$smarty->assign("email",$email);
	
	
	if ($status==1){
	$smarty->assign("active","on");
	}else{
	$smarty->assign("active","off");
	}
	
		 if ($droitd==1){
		 $smarty->assign("admin","on");
		 }else{
		  $smarty->assign("util","on");
		 }
	
	
	
	}
	
	
	if ($_GET["ad"]==1){
	
	
	if ($vverif==false){
		if ($listecatd->droit == 1){
		
		$validinsert = TRUE;
		
		if (empty($_POST['prenom'])){
		$smarty->assign("message","Erreur le pr�nom est vide");
		$validinsert= FALSE;
		}
		
		if (empty($_POST['nom'])){
		$smarty->assign("message","Erreur le nom est vide");
		$validinsert= FALSE;
		}
		
		if (empty($_POST['identifiant'])){
		$smarty->assign("message","Erreur l'identifiant est vide");
		$validinsert= FALSE;
		}
		
		if (empty($_POST['passe'])){
		$smarty->assign("message","Erreur le mot de passe est vide");
		$validinsert= FALSE;
		}
		
		if (empty($_POST['email'])){
		$smarty->assign("message","Erreur l'email est vide");
		$validinsert= FALSE;
		}
		
		if (empty($_POST['status'])){
		$smarty->assign("message","Erreur merci de s�lectionner un statut");
		$validinsert= FALSE;
		}
		
		if (empty($_POST['droit'])){
		$smarty->assign("message","Erreur merci de s�lectionner un droit");
		$validinsert= FALSE;
		}
		
		if ($_POST['groupe']=="none"){
		$smarty->assign("message","Erreur merci de choisir un groupe");
		$validinsert= FALSE;
		}
		
		if ($validinsert== TRUE){
				
							
							
			$req =  'INSERT  ';
				$req .= ' INTO table_login(';
			
				$req .= 'nom, ';
				$req .= 'prenom, ';
				$req .= 'identifiant, ';
				$req .= 'passe , ';
				$req .= 'email,  ';
				$req .= 'droit,  ';
				$req .= 'status,  ';
				$req .= 'groupe ';
				$req .= ') VALUES (';

				
				
				$req .=  	MyDb::escapequotes($_POST['nom']) . ', ';
				$req .=  	MyDb::escapequotes($_POST['prenom']) . ', ';
				$req .=  	MyDb::escapequotes($_POST['identifiant']) . ', ';
				$req .=  	MyDb::escapequotes($_POST['passe']) . ', ';
				$req .=  	MyDb::escapequotes($_POST['email']) . ', ';
				$req .=  	MyDb::escapequotes($_POST['droit']) . ', ';
				$req .=  	MyDb::escapequotes($_POST['status']) . ', ';
				$req .=  	MyDb::escapequotes($_POST['groupe']) . ' ';
				$req .= ')';
				$valeur = $connexion->execute($req);
	
				$smarty->assign("message","L'utilisateur est bien ajout�e");
			}
		}else{
	$smarty->assign("message","Impossible d'ajouter un utilisateur droit r�serv� au administrateur");
	}
		
	
	
	
	}
	}
	
	
	///$_SESSION['login']
	
	#### Droit administration

	
	if ($listecatd->droit == 1 ){
		 $gestiondroit = "on";
		 
	
	}else{
		$gestiondroit = "off";
	}
	
	
$requete_cat = 'SELECT ';
$requete_cat .= 'id, ';
$requete_cat .= 'nom, ';
$requete_cat .= 'prenom, ';
$requete_cat .= 'identifiant, ';
	$requete_cat .= 'passe, ';
	$requete_cat .= 'email, ';
	$requete_cat .= 'droit, ';
	$requete_cat .= 'status ';
	
$requete_cat .= ' FROM table_login  ';

		if ($gestiondroit=="off"){
          $requete_cat .= 'WHERE id="'.$listecatd->id.'"';
		}
		
$listecat = $connexion->queryObjectArray($requete_cat);

$nombre = array();
$smartbox = "<option>S�lectionner un utilisateur</option>";
if ($listecat==TRUE){
	foreach($listecat as $valeurcat)
			{
			
			$nombre[] = $valeurcat->id;
			$cat = $valeurcat->id;
			if ($_GET["id"]==$cat){
			$smartbox .= "<option value='gestionlogin.php?id=".$valeurcat->id."' selected>".ucfirst(strtolower($valeurcat->nom))." ". ucfirst(strtolower($valeurcat->prenom))."</option>";
			}else{
		
		if ($listecatd->droit != 1){
		if ($listecatd->id==$cat){
			$smartbox .= "<option value='gestionlogin.php?id=".$valeurcat->id."' >". ucfirst(strtolower($valeurcat->nom)) ." ". ucfirst(strtolower($valeurcat->prenom)) ."</option>";
		}
		}else{
			$smartbox .= "<option value='gestionlogin.php?id=".$valeurcat->id."' >". ucfirst(strtolower($valeurcat->nom)) ." ". ucfirst(strtolower($valeurcat->prenom)) ."</option>";
			}
		}
			}
	}
	$nb = count($nombre);
	
 
 
 /// Liste de groupe 
 
 
 $requete_groupe = 'SELECT ';
$requete_groupe .= 'id_groupe, ';
$requete_groupe .= 'nom_groupe ';
$requete_groupe .= 'FROM table_groupe  ';
$listegroupe = $connexion->queryObjectArray($requete_groupe);

$smartbox_groupe = "<option value='none'>S�lectionner le groupe</option>";
	foreach($listegroupe as $valeurgroupe)
			{
		
		
		
		
			
			$get_groupe = $valeurgroupe->id_groupe;
			if ($groupe==$get_groupe){
			$smartbox_groupe .= "<option value='".$valeurgroupe->id_groupe."' selected>".$valeurgroupe->nom_groupe."</option>";
			}else{
			$smartbox_groupe .= "<option value='".$valeurgroupe->id_groupe."' >".$valeurgroupe->nom_groupe."</option>";
			}
			}
	
	if ($edit != 1){
	$smarty->assign("nom",$_POST['nom']);
	$smarty->assign("prenom",$_POST['prenom']);
	$smarty->assign("identifiant",$_POST['identifiant']);
	$smarty->assign("passe",$_POST['passe']);
	$smarty->assign("email",$_POST['email']);	
	$smarty->assign("status",$_POST['statut']);
	$smarty->assign("droit",$_POST['droit']);
	}
	
	$smarty->assign("groupelist",$smartbox_groupe);
	$smarty->assign("gestiondroit",$gestiondroit);
	$smarty->assign("nombre",$nb);
	
	
	if ($listecatd->droit == 1){
	$smarty->assign("smartbox",$smartbox);
	}
	$smarty->display('gestion_login.html');

?>