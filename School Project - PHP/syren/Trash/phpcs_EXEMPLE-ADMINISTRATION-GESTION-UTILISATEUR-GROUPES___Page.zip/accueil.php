<?php 
#Kilian DESROCHES 
#kilian@desroches.net
include "onglet.php";
$connexion = new MyDb();
	$smarty->assign("accueil_enabled","actif");
	$smarty->assign("titre_page","Aper�u g�n�ral");
	
	$smarty->assign("title_base","Aper�u g�n�ral");
if ($listecatd->droit != 1 ){
$grade = "Mod�rateur";
}else{
$grade = "Administrateur";
}

if ($listecatd->droit == 1 ){
	$requete_cat = 'SELECT ';
	$requete_cat .= 'id';
	$requete_cat .= ' FROM table_login  ';
	$listecat = $connexion->queryObjectArray($requete_cat);
	if ($listecat==TRUE){
		foreach($listecat as $valeurcat){
				
				$nombreutilisateur[] = $valeurcat->id;
		}
	}

	$nbutilisateur = count($nombreutilisateur);

	$requete_groupe = 'SELECT ';
	$requete_groupe .= 'id_groupe';
	$requete_groupe .= ' FROM table_groupe  ';
	$listegroupe = $connexion->queryObjectArray($requete_groupe);
	if ($listegroupe==TRUE){
		foreach($listegroupe as $valeurgroupe){
				
				$nombregroupe[] = $valeurgroupe->id_groupe;
		}
	}

	$nbgroupe = count($nombregroupe);
}

	$smarty->assign("note","Bienvenue dans votre session :  <b>".$grade." ".$_SESSION['login']."</b>");

if ($listecatd->droit == 1 ){
	$smarty->assign("explication","Il y a actuellement ".$nbutilisateur." utilisateur(s) et ".$nbgroupe." groupe(s) ");
}
	
	$smarty->display('accueil.html');

?>