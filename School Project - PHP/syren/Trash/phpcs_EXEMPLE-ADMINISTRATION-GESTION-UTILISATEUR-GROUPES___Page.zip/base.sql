-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- G�n�r� le : Mardi 31 Mars 2009 � 15:41
-- Version du serveur: 5.0.27
-- Version de PHP: 5.2.1
-- 
-- Base de donn�es: `notre_site`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `table_groupe`
-- 

CREATE TABLE `table_groupe` (
  `id_groupe` int(25) NOT NULL auto_increment,
  `nom_groupe` varchar(100) NOT NULL,
  PRIMARY KEY  (`id_groupe`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Contenu de la table `table_groupe`
-- 

INSERT INTO `table_groupe` (`id_groupe`, `nom_groupe`) VALUES 
(3, 'testadd'),
(4, 'test2');

-- --------------------------------------------------------

-- 
-- Structure de la table `table_ip`
-- 

CREATE TABLE `table_ip` (
  `id` int(25) NOT NULL auto_increment,
  `ip` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- 
-- Contenu de la table `table_ip`
-- 

INSERT INTO `table_ip` (`id`, `ip`) VALUES 
(16, '127.0.0.1');

-- --------------------------------------------------------

-- 
-- Structure de la table `table_login`
-- 

CREATE TABLE `table_login` (
  `id` int(25) NOT NULL auto_increment,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `identifiant` varchar(255) NOT NULL,
  `passe` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `droit` int(25) default '1',
  `status` int(25) NOT NULL default '1',
  `groupe` int(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- 
-- Contenu de la table `table_login`
-- 

INSERT INTO `table_login` (`id`, `nom`, `prenom`, `identifiant`, `passe`, `email`, `droit`, `status`, `groupe`) VALUES 
(2, 'desroches', 'Kilian', 'kdesroches', 'passe', 'kilian@desroches.net', 1, 1, 3),
(13, 'test', 'test', 'moderateur', 'moderateur', 'test@test.com', 2, 1, 4);
