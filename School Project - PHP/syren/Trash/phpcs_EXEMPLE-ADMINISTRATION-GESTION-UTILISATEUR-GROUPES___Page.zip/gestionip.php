<?php 
#Kilian DESROCHES 
#kilian@desroches.net

include "onglet.php";
require_once('class/MyDb.lib.php');
	require_once('config.inc.php');
	$smarty->assign("gestion_enabled","actif");
	$smarty->assign("ip_enabled","actif");
	$smarty->assign("titre_page","Configuration des IP");
	$smarty->assign("explication","Aper�u de l'ensemble des configurations.");
	$smarty->assign("title_base","Configuration IP");

	 	 	 	 	 	 	 	 	 	
	
	$connexion = new MyDb();
	
	
	if ($listecatd->droit != 1 ){
		 $smarty->assign("message","Acc�s uniquement autoris� au Administrateur");
	$smarty->assign("desactive","on");
	

	}else{
	
	$smarty->assign("desactive","off");
	}
	
	
	if (!empty($_GET["id"])){
	
	
	if ($_GET["sup"]==1){
	
	
		$reqd =  'DELETE FROM ';
		$reqd .= ' table_ip  ';
		$reqd .= 'WHERE id="'.$_GET['id'].'"';
		$valeurd = $connexion->execute($reqd);
		
		$del=1;
	}

	
	
	if ($_GET["mod"]==1){
		$reqd =  'UPDATE  ';
		$reqd .= ' table_ip SET ';
		$reqd .= 'ip="'.$_POST['ip'].'" ';
		
	
		$reqd .= 'WHERE id="'.$_GET['id'].'"';
		$valeurd = $connexion->execute($reqd);
		
		$mod=1;
	}
	
	
	$requete_cat = 'SELECT ';
	$requete_cat .= 'id, ';
	$requete_cat .= 'ip ';

	$requete_cat .= 'FROM table_ip WHERE  id='.$_GET["id"].'';
	$listecat = $connexion->querySingleItemObject($requete_cat);

	$id = $listecat->id;
	$ip = $listecat->ip;



	
	
	if ($mod==1){
	$formedit = "Modification effective <br>";
	}
	
	if ($del==1){
	$formedit = "Suppression effective <br>";
	}
	
	$smarty->assign("message","Edition de l'ip ".$ip."<br>".$formedit." [ <a href='gestionip.php'><b>Nouvelle IP</b></a> ]");
	$smarty->assign("modif",1);
		$smarty->assign("id",$id);
	$smarty->assign("ip",$ip);
	
	}
	
	
	if ($_GET["ad"]==1){
	if (!empty($_POST["ip"])){
	
	$requeteverif =  'SELECT ip  ';
							$requeteverif .= 'FROM table_ip   ';
							$requeteverif .= 'WHERE ';
							$requeteverif .= 'id = "'. $_POST['id'].'"'; 
							$vverif = $connexion->querySingleItemObject($requeteverif);
	
	if ($vverif==false){
			$req =  'INSERT  ';
				$req .= ' INTO table_ip(';
			
				
				$req .= 'ip ';
				
			
			
				$req .= ') VALUES (';

				
				
			
				$req .=  	MyDb::escapequotes($_POST['ip']) . ' ';
			
				
				$req .= ')';
				$valeur = $connexion->execute($req);
	
	$smarty->assign("message","L'IP est bien ajout�e");
	}else{
	$smarty->assign("message","Erreur l'IP existe d�j�");
	}
	
	}
	}
	
$requete_cat = 'SELECT ';
$requete_cat .= 'id, ';
$requete_cat .= 'ip ';
	
	
	
	
	
$requete_cat .= 'FROM table_ip  ';
$listecat = $connexion->queryObjectArray($requete_cat);

$nombre = array();
$smartbox = "<option>S�lectionner une IP</option>";
	foreach($listecat as $valeurcat)
			{
		
			$nombre[] = $valeurcat->id;
			$cat = $valeurcat->id;
			if ($_GET["id"]==$cat){
			$smartbox .= "<option value='gestionip.php?id=".$valeurcat->id."' selected>".$valeurcat->ip."</option>";
			}else{
			$smartbox .= "<option value='gestionip.php?id=".$valeurcat->id."' >".$valeurcat->ip."</option>";
			}
			}
	
	$nb = count($nombre);
	

	
	
	
	


	$smarty->assign("nombre",$nb);
$smarty->assign("smartbox",$smartbox);
	$smarty->display('gestion_ip.html');

?>