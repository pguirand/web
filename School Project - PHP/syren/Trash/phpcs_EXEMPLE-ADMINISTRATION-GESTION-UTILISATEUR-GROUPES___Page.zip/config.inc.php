<?php
#Kilian DESROCHES 
#kilian@desroches.net

/** Les identifiants Mysql **/
$GLOBALS['SQL_SERVER'] = 'localhost';
$GLOBALS['SQL_LOGIN'] = 'root';
$GLOBALS['SQL_PASSWORD'] = '';
$GLOBALS['SQL_DATABASE'] = 'notre_site';



$GLOBALS['SHOW_SQL'] = FALSE;
$GLOBALS['SHOW_SQL_ERRORS'] = TRUE;


//Nom du serveur 
$GLOBALS['SERVER_NAME'] = $_SERVER['HTTP_HOST'];
$GLOBALS['RACINE'] = $_SERVER['DOCUMENT_ROOT'].'';
$GLOBALS['ADRESSE'] = 'http://'.$_SERVER['HTTP_HOST'];
?>
