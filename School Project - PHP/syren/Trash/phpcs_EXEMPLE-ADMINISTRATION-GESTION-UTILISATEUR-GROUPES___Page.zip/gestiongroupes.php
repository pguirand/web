<?php 
#Kilian DESROCHES 
#kilian@desroches.net

include "onglet.php";
require_once('class/MyDb.lib.php');
	require_once('config.inc.php');
	$smarty->assign("gestion_enabled","actif");
	$smarty->assign("groupe_enabled","actif");
	$smarty->assign("titre_page","Configuration des groupes");
	$smarty->assign("explication","Aper�u de l'ensemble des configurations");
	$smarty->assign("title_base","Configurations");

	 	 	 	 	 	 	 	 	 	
	
	$connexion = new MyDb();
	
	if (!empty($_GET["idgroupe"])){
	
	
	if ($_GET["sup"]==1){
	
	$requete_verifsitecl = 'SELECT ';
	$requete_verifsitecl .= 'groupe  ';
	$requete_verifsitecl .= 'FROM table_login WHERE groupe="'.$_GET["idgroupe"].'"  ';
	$listeverifsitecl = $connexion->querySingleItemObject($requete_verifsitecl);
	
	if ($listeverifsitecl==TRUE){ // on lock si des utilisateurs sont rattach� au groupe
					$lock = "on";
					$note = "Impossible de supprimer le groupe , des utilisateurs sont rattach� au groupe. ";
				$smarty->assign("message",$note);
				
				}else{
		$reqd =  'DELETE FROM ';
		$reqd .= ' table_groupe  ';
		$reqd .= 'WHERE id_groupe="'.$_GET['idgroupe'].'"';
	//	$valeurd = $connexion->execute($reqd);
		
		$del=1;
		}
	}

	
	
	if ($_GET["mod"]==1){
		$reqd =  'UPDATE  ';
		$reqd .= ' table_groupe SET ';
		$reqd .= 'nom_groupe="'.$_POST['groupe'].'" ';
	
		$reqd .= 'WHERE id_groupe="'.$_GET['idgroupe'].'"';
		$valeurd = $connexion->execute($reqd);
		
		$mod=1;
	}
	
	
	
	
	
	$requete_cat = 'SELECT ';
	$requete_cat .= 'id_groupe, ';
	$requete_cat .= 'nom_groupe ';

	$requete_cat .= 'FROM table_groupe WHERE  id_groupe='.$_GET["idgroupe"].'';
	$listecat = $connexion->querySingleItemObject($requete_cat);

	$nom_groupe = $listecat->nom_groupe;
	

	
	
	if ($mod==1){
	$formedit = "Modification effective <br>";
	}
	
	if ($del==1){
	$formedit = "Suppression effective <br>";
	}
	
	if (empty($note)){
	$smarty->assign("message","Edition du groupe ".$nom_groupe."<br>".$formedit." [ <a href='gestiongroupes.php'><b>Nouveau groupe</b></a> ]");
	}
	$smarty->assign("modif",1);
	$smarty->assign("groupe",$nom_groupe);
	$smarty->assign("idgroupe",$_GET["idgroupe"]);
	}
	
	
	if ($_GET["ad"]==1){
	if (!empty($_POST["groupe"])){
	
	$requeteverif =  'SELECT nom_groupe  ';
							$requeteverif .= 'FROM table_groupe   ';
					
							$requeteverif .= 'WHERE ';
							$requeteverif .= 'nom_groupe = "'. $_POST['groupe'].'"'; 
							$vverif = $connexion->querySingleItemObject($requeteverif);
	
	if ($vverif==false){
			$req =  'INSERT  ';
				$req .= ' INTO table_groupe(';
			
				
				$req .= 'nom_groupe ';
				
			
				$req .= ') VALUES (';

				
				
			
				$req .=  	MyDb::escapequotes($_POST['groupe']) . ' ';
		
				$req .= ')';
				$valeur = $connexion->execute($req);
	
	$smarty->assign("message","Le groupe est bien ajout�e");
	}else{
	$smarty->assign("message","Erreur le groupe existe d�j�");
	}
	
	}
	}
	
	

	
	
$requete_cat = 'SELECT ';
$requete_cat .= 'id_groupe, ';
$requete_cat .= 'nom_groupe ';

	
	
$requete_cat .= 'FROM table_groupe  ';
$listecat = $connexion->queryObjectArray($requete_cat);

$nombre = array();
$smartbox = "<option>S�lectionner votre groupe</option>";

if ($listecat==TRUE){
	foreach($listecat as $valeurcat)
			{
		
		
		
		
			$nombre[] = $valeurcat->id_groupe;
			$groupe = $valeurcat->id_groupe;
			if ($_GET["idcat"]==$groupe){
			$smartbox .= "<option value='gestiongroupes.php?idgroupe=".$valeurcat->id_groupe."' selected>".$valeurcat->nom_groupe."</option>";
			}else{
			$smartbox .= "<option value='gestiongroupes.php?idgroupe=".$valeurcat->id_groupe."' >".$valeurcat->nom_groupe."</option>";
			}
			}
}
	
	$nb = count($nombre);

	$smarty->assign("info",$info);
	$smarty->assign("lock",$lock);

		$smarty->assign("nombre",$nb);
	$smarty->assign("smartbox",$smartbox);
	$smarty->display('gestion_groupe.html');

?>